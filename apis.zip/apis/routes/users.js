const express = require('express'); 
const router = express.Router();

//importing model
const User = require('../models/user');

//Routes
//gets all posts
router.post('/login',async(req,res)=>{

    var Email = req.body.Email;
    var Password = req.body.Password;

    User.findOne({Email : Email , Password : Password}, function(err,user){
        if(err){
            return res.status(500).send();
        }
        if(!user)
        {
            return res.status(404).send("Invalid Credentials");
        }
        req.session.user = user;
        return res.status(200).send("welcome");
    })
    
});


//post 
router.post('/register',async(req,res)=>{
    const user = new User({
        FirstName : req.body.FirstName,
        LastName : req.body.LastName,
        Email : req.body.Email,
        Password : req.body.Password
    });
    try{
        const saveduser = await user.save();
        res.json(saveduser);
    }catch(err){
        res.json({message : err});
    }
    
    
});

router.get('/home',function(req,res){
    if(!req.session.user){
        return res.status(401).send();
    }

    return res.status(200).send("welcome to dashboard");

})

router.get('/logout',(req,res)=>{
    req.session.destroy();

    return res.status(200).send();

})

module.exports = router;