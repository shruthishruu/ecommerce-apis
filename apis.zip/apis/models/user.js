const mongoose = require('mongoose');


//defining schema 
const UserSchema = mongoose.Schema({

    FirstName : {
        type : String,
        required : true
    },
    LastName:{
        type:String,
        required : true
    },
    Email:{
        type:String,
        required : true
    },
    Password:{
        type:String,
        required : true
    },
    date : {
        type : Date,
        default : Date.now
    }

});


//we export it by giving name and which schema it has to use
module.exports = mongoose.model('myUser',UserSchema);