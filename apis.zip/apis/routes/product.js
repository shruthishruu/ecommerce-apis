const express = require('express'); 
const router = express.Router();

//importing model
const Product = require('../models/products');
const Cart = require('../models/cart');

router.post('/add',async(req,res)=>{
    const product = new Product({
        Name : req.body.Name,
        description : req.body.description,
        image : req.body.image,
        price : req.body.price,
        catagoroy : req.body.catagoroy,
        comments : req.body.comments
    });
    try{
        const savedprod = await product.save();
        res.json(savedprod);
    }catch(err){
        res.json({message : err});
    }
    
    
});

router.get('/',async(req,res)=>{
    try {
        const prods = await Product.find();
        res.json(prods);
    } catch (err) {
        res.json({message : err});
    }
});


router.get('/:id',async(req,res)=>{

    try {
        const prods = await Product.findById(req.params.id);
        res.json(prods);
    } catch (err) {
        res.json({message : err});
    }
    
});

router.post('/addCart/:id',async(req,res)=>{
    
    const prod = await Product.findById(req.params.id);

    const cart = new Cart(prod);
    try{
        const addCart = await cart.save();
        res.json(savedprod);
    }catch(err){
        res.json({message : err});
    }
    
    
});
/*
//Routes
//gets all posts
router.post('/login',async(req,res)=>{

    var Email = req.body.Email;
    var Password = req.body.Password;

    User.findOne({Email : Email , Password : Password}, function(err,user){
        if(err){
            return res.status(500).send();
        }
        if(!user)
        {
            return res.status(404).send("Invalid Credentials");
        }
        req.session.user = user;
        return res.status(200).send("welcome");
    })
    
});


//post 
router.post('/register',async(req,res)=>{
    const user = new User({
        FirstName : req.body.FirstName,
        LastName : req.body.LastName,
        Email : req.body.Email,
        Password : req.body.Password
    });
    try{
        const saveduser = await user.save();
        res.json(saveduser);
    }catch(err){
        res.json({message : err});
    }
    
    
});

router.get('/home',function(req,res){
    if(!req.session.user){
        return res.status(401).send();
    }

    return res.status(200).send("welcome to dashboard");

})

router.get('/logout',(req,res)=>{
    req.session.destroy();

    return res.status(200).send();

})
*/
module.exports = router;