const express = require('express'); 
const router = express.Router();

//importing model
const Product = require('../models/cart');

module.exports = router;