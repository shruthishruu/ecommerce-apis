const mongoose = require('mongoose');


//defining schema 
const cartSchema = mongoose.Schema({

    Name : {
        type : String,
        required : true
    },
    description:{
        type:String,
        required : true
    },
    image :{
        type : String,
        required:true
    },
    price:{
        type:String,
        required : true
    },
    quantity:{
        type : Number,
        default : 1
    },
    date : {
        type : Date,
        default : Date.now
    }

});


//we export it by giving name and which schema it has to use
module.exports = mongoose.model('myCart',cartSchema);